package com.example.contactlist_using_get_post;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContactlistUsingGetPostApplication  {

	public static void main(String[] args) throws Exception {
		SpringApplication.run(ContactlistUsingGetPostApplication.class, args);
	}

}
