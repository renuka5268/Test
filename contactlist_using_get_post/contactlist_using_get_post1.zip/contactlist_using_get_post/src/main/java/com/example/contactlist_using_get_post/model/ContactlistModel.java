package com.example.contactlist_using_get_post.model;
import com.example.contactlist_using_get_post.Repository.ContactlistRepository;
import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;
import java.util.Scanner;

public class ContactlistModel {
    @Autowired
    ContactlistRepository contactlistRepository;


}

