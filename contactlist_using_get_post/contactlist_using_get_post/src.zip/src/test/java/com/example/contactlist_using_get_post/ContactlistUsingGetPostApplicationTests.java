package com.example.contactlist_using_get_post;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ContactlistUsingGetPostApplicationTests {

	@Test
	void contextLoads() {
	}

}
